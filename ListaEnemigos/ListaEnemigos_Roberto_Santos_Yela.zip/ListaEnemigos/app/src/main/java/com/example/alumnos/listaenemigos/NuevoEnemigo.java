package com.example.alumnos.listaenemigos;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;

public class NuevoEnemigo extends Fragment {

    /* Variables publicas de elementos */
    ImageView fotoEnemigo;
    Button boton;
    Button botonFoto;
    EditText nombreEnemigo;
    RatingBar nivelOdio;

    /* Variable que almacena la foto tomada con la camara */
    String fotoGuardada;

    /* Constante necesaria para realizar la peticion de la camara*/
    static final int CODIGO_PETICION = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.nuevo_enemigo,container,false);

        /* Asignacion de las referencias XML a los elementos */
        fotoEnemigo = view.findViewById(R.id.imagenEnemigo);
        nombreEnemigo = view.findViewById(R.id.nombreEnemigo);
        boton = view.findViewById(R.id.anadirEnemigo);
        botonFoto = view.findViewById(R.id.anadirFotoEnemigo);
        nivelOdio = view.findViewById(R.id.nivelOdio);

        /* Evento onClick en este elemento */
        botonFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                if(intent.resolveActivity(getActivity().getPackageManager()) != null) {

                    getActivity().startActivityForResult(intent, CODIGO_PETICION);
                }

            }
        });

        /* Evento onClick en este elemento */
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendNombre();

            }
        });

        return view;
    }

    /**
     * Metodo que manda la imagen guardada a la previsualizacion de la foto del enemigo.
     * @param uri Recibe la imagen
     */
    void sendImage(Uri uri) {

        fotoGuardada = uri.toString();
        fotoEnemigo.setImageURI(uri);
    }

    /* Metodo que obtiene el nombre del campo de texto del fragment y lo manda al MainActivity */
    void sendNombre(){

        String nombre = nombreEnemigo.getText().toString();
        float odio = nivelOdio.getRating();
        Enemigo enemigo = new Enemigo( fotoGuardada, nombre, odio);

        MainActivity mainActivity = (MainActivity) getActivity();
        mainActivity.sendEnemigo(enemigo);

    }

}
