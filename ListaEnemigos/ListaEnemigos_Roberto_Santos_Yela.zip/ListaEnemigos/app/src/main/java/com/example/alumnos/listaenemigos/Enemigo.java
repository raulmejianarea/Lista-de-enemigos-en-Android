package com.example.alumnos.listaenemigos;

import android.graphics.Bitmap;
import android.net.Uri;


/* Clase que sirve como patron para la creacion de nuevos enemigos */
public class Enemigo {

    String image;
    String nombre;
    float rating;

    /**
     * Constructor de clase Enemigo.
     * @param image Es el parametro que almacena la imagen del enemigo.
     * @param nombre Es el parametro que almacena el nombre del enemigo.
     * @param rating Es el parametro que almacena el rating de odio del enemigo.
     */
    Enemigo (String image, String nombre, float rating){

        this.image = image;
        this.nombre = nombre;
        this.rating = rating;

    }

}
